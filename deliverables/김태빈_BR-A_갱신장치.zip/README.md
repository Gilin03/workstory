# 김태빈 BR-A 자기소개 사이트

고난에서 시작해 질문·협업·재시도로 지금의 방향에 도착한 과정을 공개 사이트와 지원 문서로 정리한 결과물입니다. 화면은 숫자보다 1,323자 자기소개 본편이 먼저 읽히는 편집형 구조로 구성했습니다.

## 실행

```powershell
npm install
npm run generate
npm run check:content
npm run dev
```

브라우저에서 표시된 로컬 주소를 엽니다. 정적 사이트이므로 로그인·Supabase·데이터베이스가 필요하지 않습니다.

## 새 기록으로 갱신하기

1. `inputs/`에 `attendance.json`과 `submissions.json`을 예시 파일과 같은 구조로 넣습니다. 현재 `attendance.json`은 2026-09-17 화면에서 확인한 출석 summary를, `submissions.json`은 과제 12 진행 중인 현재 상황에 따라 1~11번 제출 완료를 담고 있으며, 리추얼 기록은 `ritual-history.json`으로 둡니다.
2. `npm run generate`를 실행해 `src/generated/site-data.json`, `metrics.json`, `candidates.md`를 만듭니다.
3. `candidates.md`의 날짜·근거를 검토하고 승인한 문장만 `src/content/approved.json`에 반영한 뒤 `npm run build`로 사이트를 다시 빌드합니다.

같은 입력에 같은 결과를 보장하기 위해 생성기는 외부 API와 현재 시각을 사용하지 않습니다. 결과의 기준일은 입력 기록에서 계산하며, 결정론 테스트는 두 임시 폴더의 출력 내용을 비교합니다.

## 제출 전 확인

- `docs/content-review.md`의 한 줄 소개·첫 문장·마지막 문장을 직접 선택·수정합니다.
- `checklist.md`에서 BRA-C01~C21의 완료·부분 완료·사용자 확인 필요 항목을 마지막으로 점검합니다.
- `src/content/approved.json`의 공개 이메일은 `xoqls081215@gmail.com`으로 확정되어 있으며, 다른 공개 연락 수단으로 바꿀 때만 `isPlaceholder`를 수정합니다.
- 연락처를 바꾼 뒤 `python scripts/create_application_doc.py`로 DOCX를 다시 만들고 `public/documents/`에도 복사합니다.
- 10번 논문 PDF와 지원 DOCX의 링크가 새 시크릿 창에서 로그인 없이 열리는지 확인합니다.
- 다른 사람의 실명·연락처·비밀번호·토큰·API 키를 넣지 않았는지 `npm run check:privacy`로 확인합니다.

## 검증 명령

```powershell
npm run test:generator
npm run check:content
npm run check:privacy
npm run build
```

## 산출물

- 공개 사이트: Vercel 정적 배포 후 HTTPS URL
- 지원 문서: `deliverables/김태빈_지원서_묶음.docx`
- 갱신 장치: `deliverables/김태빈_BR-A_갱신장치.zip`

## Vercel 공개 배포

현재 환경에는 유효한 Vercel·GitHub 로그인 세션이 없으므로 배포와 GitHub push는 사용자가 인증한 뒤 실행합니다.

```powershell
npx vercel login
npx vercel --prod
```

배포가 끝나면 출력된 `https://...` 주소 하나를 제출용 결과물 URL로 사용합니다. 토큰을 파일·README·소스에 저장하지 않습니다.

현재 제공된 원자료에는 리추얼 기록·출석 화면 summary·1~11번 제출 현황이 있어 사이트에는 리추얼 기록, 출석 보조 수치, `11/11개` 제출 현황이 표시됩니다. 출석 보조 수치에는 원자료의 기준일이 함께 표시되며, 최신 출석을 반영하려면 `inputs/attendance.json`을 교체하고 `npm run generate`를 실행합니다. 출석률은 과제 필수 항목이 아니므로 표시하지 않습니다. 제출 현황은 `inputs/submissions.json`의 과제별 상태를 계산하며, 없는 숫자는 만들지 않습니다.
